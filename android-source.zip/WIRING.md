# Anti-Beer Goggles: wiring and power notes

Assumes **one protected 3.7V nominal LiPo cell**, a compatible LiPo charger/protection arrangement,
an existing 5V boost module for the ESP32-S3 Mini, a *regulated* fan supply near 3.0V,
and a logic-level N-channel MOSFET. Verify actual board pin labels and fan rating before wiring.

## Fan switch — ESP32 GPIO4

```text
                      FAN POWER SUPPLY: regulated 3.0 V
                           (+)             (-)
                            |               |
                         Fan (+)            +---------+--- ESP GND
                            |                         |
                           FAN                        |
                            |                         |
                         Fan (-)                      |
                            |                         |
                         Drain                        |
                      N-MOSFET                       |
  ESP32 GPIO4 -- 100..220Ω -- Gate                    |
                            |                         |
                          10kΩ                        |
                            |                         |
   Common GND --------------+-------- Source ---------+
```

- Fan **positive** goes to a separately appropriate *regulated 3.0V rail*, not 5V or GPIO.
- Fan **negative** goes to the MOSFET drain; MOSFET source to common ground.
- ESP32-S3 GPIO4 controls MOSFET gate through a 100–220Ω series resistor.
- Fit a 10kΩ pull-down from gate to ground so the fan is off while ESP32 boots.
- Fan current was previously said to be about **100mA**. Choose a MOSFET that switches properly at a **3.3V gate drive**. A specific IRLZ44N may work at 100mA but is not fully specified at 3.3V gate voltage; verify it in your circuit.
- The user elected not to fit an external flyback diode; this project doesn't require that modification to build the firmware. Review real fan electrical behavior before prolonged use.

## ESP power

```text
 Protected 1-cell LiPo output (+) ----> 5V boost IN+
 Protected 1-cell LiPo output (-) ----> 5V boost IN-
 5V boost OUT+ -----------------------> ESP board input labelled 5V/VIN (VERIFY LABEL)
 5V boost OUT- -----------------------> ESP GND
```

**Never feed 5V into the ESP32 3V3 or GPIO pins.** Verify the Mini's 5V/VIN input and onboard regulator before connecting power. A LiPo cell reaches about **4.2V when charged**, so it should not directly supply a fan rated only for 3.0V unless the original unit's electronics properly regulate the output.

The charger module must be suitable for the exact battery chemistry and have appropriate LiPo cell protection. Use the *protected output* ground where your module provides one; don't bypass protection with an inappropriate ground connection. Only charge under the charger's recommended arrangement.

## Battery monitoring — ESP32 GPIO1

```text
Protected LiPo (+) ----- [10kΩ] -----+------- GPIO1 (ESP32-S3 ADC input)
                                    |
                                  [10kΩ]
                                    |
Protected LiPo (-) ------------------+------- ESP GND
```

- Place the divider **before the 5V boost**, so it measures actual cell voltage.
- Two equal 10kΩ resistors reduce 4.2V to about 2.1V at GPIO1.
- The resistors draw about 0.21mA continuously whenever they are connected to the battery.
- No capacitor is required; the firmware averages multiple ADC measurements.
- Battery percentage is an estimate, not an indication of proper battery-protection status.

**Don't connect battery positive directly to the ESP32's GPIO1 or 3V3 pin.**
