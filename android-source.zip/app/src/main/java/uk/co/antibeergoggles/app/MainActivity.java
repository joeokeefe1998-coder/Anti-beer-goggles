package uk.co.antibeergoggles.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Color;
import org.json.JSONObject;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * Offline Android Bluetooth Low Energy controller for the ESP32-S3 firmware
 * provided in esp32_firmware. No account, analytics, or Internet permission.
 */
@SuppressLint("MissingPermission") // Runtime nearby-device permissions checked before BLE actions.
public final class MainActivity extends Activity {
    private static final UUID SERVICE_UUID = UUID.fromString("c83e0001-7cc4-4f8a-a0ad-0d2041151337");
    private static final UUID SPEED_UUID   = UUID.fromString("c83e0002-7cc4-4f8a-a0ad-0d2041151337");
    private static final UUID BATTERY_UUID = UUID.fromString("c83e0003-7cc4-4f8a-a0ad-0d2041151337");
    private static final UUID CCCD_UUID    = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    private static final int REQUEST_BLE = 110;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final Map<String, BluetoothDevice> devices = new HashMap<>();
    private final ArrayDeque<byte[]> pending = new ArrayDeque<>();
    private WebView webView;
    private BluetoothAdapter adapter;
    private BluetoothLeScanner scanner;
    private BluetoothGatt gatt;
    private BluetoothGattCharacteristic speedCharacteristic;
    private BluetoothGattCharacteristic batteryCharacteristic;
    private boolean scanning = false;
    private boolean connected = false;
    private boolean writing = false;
    private int lastRequestedSpeed = 0;
    private String pendingDeviceAddress = null;
    private String status = "DISCONNECTED";

    @Override public void onCreate(Bundle savedState) {
        super.onCreate(savedState);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().getDecorView().setSystemUiVisibility(0);
        BluetoothManager manager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        adapter = manager == null ? null : manager.getAdapter();
        webView = new WebView(this);
        webView.setBackgroundColor(Color.BLACK);
        webView.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.addJavascriptInterface(new Bridge(), "AndroidControl");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return !url.startsWith("file:///android_asset/");
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !request.getUrl().toString().startsWith("file:///android_asset/");
            }
            @Override public void onPageFinished(WebView view, String url) {
                showBleStatus(status, connected);
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private boolean hasBlePermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        }
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void askBlePermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            requestPermissions(new String[] { Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_CONNECT }, REQUEST_BLE);
        } else {
            requestPermissions(new String[] { Manifest.permission.ACCESS_FINE_LOCATION }, REQUEST_BLE);
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode != REQUEST_BLE) return;
        if (!hasBlePermissions()) {
            showBleStatus("BLUETOOTH PERMISSION REQUIRED", false);
            return;
        }
        if (pendingDeviceAddress != null) {
            String address = pendingDeviceAddress;
            pendingDeviceAddress = null;
            connect(address);
        } else {
            startScan();
        }
    }

    private void js(String code) {
        mainHandler.post(() -> {
            if (webView != null) webView.evaluateJavascript(code, null);
        });
    }

    private void showBleStatus(String message, boolean isConnected) {
        status = message;
        connected = isConnected;
        js("window.app.onBleState(" + JSONObject.quote(message) + "," + isConnected + ");");
    }

    private final ScanCallback scanCallback = new ScanCallback() {
        @Override public void onScanResult(int callbackType, ScanResult result) {
            BluetoothDevice device = result.getDevice();
            String address = device.getAddress();
            String name = result.getScanRecord() == null ? null : result.getScanRecord().getDeviceName();
            if (name == null || name.isEmpty()) name = device.getName();
            boolean knownService = result.getScanRecord() != null
                && result.getScanRecord().getServiceUuids() != null
                && result.getScanRecord().getServiceUuids().stream()
                    .anyMatch(parcel -> SERVICE_UUID.equals(parcel.getUuid()));
            boolean likelyDevice = name != null && (name.toLowerCase(Locale.ROOT).contains("antibeer")
                || name.toLowerCase(Locale.ROOT).contains("exfog")
                || name.toLowerCase(Locale.ROOT).contains("defog"));
            if (!likelyDevice && !knownService) return;
            if (name == null || name.isEmpty()) name = "Anti-Beer Goggles";
            boolean fresh = !devices.containsKey(address);
            devices.put(address, device);
            if (fresh) js("window.app.onDeviceFound(" + JSONObject.quote(name) + ","
                    + JSONObject.quote(address) + "," + result.getRssi() + ");");
        }
        @Override public void onScanFailed(int errorCode) {
            showBleStatus("SCAN FAILED (" + errorCode + ")", false);
            stopScan();
        }
    };

    private void startScan() {
        if (adapter == null) {
            showBleStatus("BLUETOOTH NOT SUPPORTED", false);
            return;
        }
        if (!hasBlePermissions()) {
            askBlePermissions();
            return;
        }
        if (!adapter.isEnabled()) {
            showBleStatus("SWITCH ON BLUETOOTH", false);
            startActivity(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE));
            return;
        }
        stopScan();
        devices.clear();
        js("window.app.onScanStart();");
        scanner = adapter.getBluetoothLeScanner();
        if (scanner == null) {
            showBleStatus("SCANNER UNAVAILABLE", false);
            return;
        }
        try {
            scanner.startScan(scanCallback);
            scanning = true;
            js("window.app.onScanProgress(true);");
            mainHandler.postDelayed(() -> stopScan(), 12000);
        } catch (Exception ex) {
            showBleStatus("SCAN ERROR: " + ex.getClass().getSimpleName(), false);
        }
    }

    private void stopScan() {
        if (scanning && scanner != null && hasBlePermissions()) {
            try { scanner.stopScan(scanCallback); } catch (Exception ignored) { }
        }
        scanning = false;
        js("window.app.onScanProgress(false);");
    }

    private void connect(String address) {
        if (!hasBlePermissions()) {
            pendingDeviceAddress = address;
            askBlePermissions();
            return;
        }
        BluetoothDevice device = devices.get(address);
        if (device == null) {
            showBleStatus("SCAN AND SELECT YOUR DEVICE", false);
            return;
        }
        stopScan();
        disconnect();
        showBleStatus("CONNECTING…", false);
        try {
            gatt = device.connectGatt(this, false, callback, BluetoothDevice.TRANSPORT_LE);
            if (gatt == null) showBleStatus("CONNECTION FAILED", false);
        } catch (Exception ex) {
            showBleStatus("CONNECTION FAILED", false);
        }
    }

    private void disconnect() {
        pending.clear();
        writing = false;
        speedCharacteristic = null;
        batteryCharacteristic = null;
        BluetoothGatt old = gatt;
        gatt = null;
        if (old != null) {
            try { old.disconnect(); old.close(); } catch (Exception ignored) { }
        }
        showBleStatus("DISCONNECTED", false);
    }

    private final BluetoothGattCallback callback = new BluetoothGattCallback() {
        @Override public void onConnectionStateChange(BluetoothGatt current, int statusCode, int state) {
            if (current != gatt) return;
            if (statusCode == BluetoothGatt.GATT_SUCCESS && state == BluetoothProfile.STATE_CONNECTED) {
                showBleStatus("DISCOVERING SERVICES…", false);
                current.discoverServices();
            } else if (state == BluetoothProfile.STATE_DISCONNECTED || statusCode != BluetoothGatt.GATT_SUCCESS) {
                mainHandler.post(() -> {
                    if (gatt == current) {
                        pending.clear();
                        writing = false;
                        speedCharacteristic = null;
                        batteryCharacteristic = null;
                        gatt = null;
                        current.close();
                        showBleStatus("DISCONNECTED", false);
                    }
                });
            }
        }

        @Override public void onServicesDiscovered(BluetoothGatt current, int statusCode) {
            if (current != gatt) return;
            BluetoothGattService service = current.getService(SERVICE_UUID);
            if (statusCode != BluetoothGatt.GATT_SUCCESS || service == null) {
                showBleStatus("INCOMPATIBLE FIRMWARE", false);
                return;
            }
            speedCharacteristic = service.getCharacteristic(SPEED_UUID);
            batteryCharacteristic = service.getCharacteristic(BATTERY_UUID);
            if (speedCharacteristic == null || batteryCharacteristic == null) {
                showBleStatus("MISSING BLE CHARACTERISTICS", false);
                return;
            }
            showBleStatus("CONNECTED", true);
            boolean subscribed = current.setCharacteristicNotification(batteryCharacteristic, true);
            BluetoothGattDescriptor cccd = batteryCharacteristic.getDescriptor(CCCD_UUID);
            if (subscribed && cccd != null) {
                if (Build.VERSION.SDK_INT >= 33) {
                    int result = current.writeDescriptor(cccd, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                    if (result != BluetoothGatt.GATT_SUCCESS) current.readCharacteristic(speedCharacteristic);
                } else {
                    cccd.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                    if (!current.writeDescriptor(cccd)) current.readCharacteristic(speedCharacteristic);
                }
            } else {
                current.readCharacteristic(speedCharacteristic);
            }
        }

        @Override public void onDescriptorWrite(BluetoothGatt current, BluetoothGattDescriptor desc, int statusCode) {
            if (current == gatt && speedCharacteristic != null) current.readCharacteristic(speedCharacteristic);
        }

        @Override public void onCharacteristicRead(BluetoothGatt current, BluetoothGattCharacteristic characteristic, int statusCode) {
            if (statusCode == BluetoothGatt.GATT_SUCCESS) processReading(characteristic.getUuid(), characteristic.getValue());
            afterRead(current, characteristic);
        }

        @Override public void onCharacteristicRead(BluetoothGatt current, BluetoothGattCharacteristic characteristic,
                                                    byte[] value, int statusCode) {
            if (statusCode == BluetoothGatt.GATT_SUCCESS) processReading(characteristic.getUuid(), value);
            afterRead(current, characteristic);
        }

        private void afterRead(BluetoothGatt current, BluetoothGattCharacteristic characteristic) {
            if (current == gatt && SPEED_UUID.equals(characteristic.getUuid()) && batteryCharacteristic != null) {
                current.readCharacteristic(batteryCharacteristic);
            }
        }

        @Override public void onCharacteristicChanged(BluetoothGatt current, BluetoothGattCharacteristic characteristic) {
            if (current == gatt) processReading(characteristic.getUuid(), characteristic.getValue());
        }

        @Override public void onCharacteristicChanged(BluetoothGatt current, BluetoothGattCharacteristic characteristic, byte[] value) {
            if (current == gatt) processReading(characteristic.getUuid(), value);
        }

        @Override public void onCharacteristicWrite(BluetoothGatt current, BluetoothGattCharacteristic characteristic, int statusCode) {
            if (current != gatt) return;
            mainHandler.post(() -> {
                writing = false;
                if (statusCode != BluetoothGatt.GATT_SUCCESS) js("window.app.onSendError();");
                flushWrites();
            });
        }
    };

    private void processReading(UUID uuid, byte[] data) {
        if (data == null || data.length == 0) return;
        if (BATTERY_UUID.equals(uuid)) {
            int pct = data[0] & 255;
            int millivolts = data.length >= 3 ? ((data[1] & 255) | ((data[2] & 255) << 8)) : 0;
            if (pct > 100) pct = 100;
            js("window.app.onBattery(" + pct + "," + (millivolts / 1000.0f) + ");");
        } else if (SPEED_UUID.equals(uuid)) {
            int speed = Math.min(100, data[0] & 255);
            lastRequestedSpeed = speed;
            js("window.app.onFanApplied(" + speed + ");");
        }
    }

    private void queueSpeed(int speed) {
        if (!connected || speedCharacteristic == null || gatt == null) {
            js("window.app.onSendError();");
            return;
        }
        lastRequestedSpeed = Math.max(0, Math.min(speed, 100));
        // Coalesce rapid slider movement, retaining timer commands.
        pending.removeIf(bytes -> bytes.length == 1);
        pending.addLast(new byte[]{(byte) lastRequestedSpeed});
        flushWrites();
    }

    private void queueSleep(int minutes) {
        if (!connected || speedCharacteristic == null || gatt == null) {
            js("window.app.onSendError();");
            return;
        }
        pending.addLast(new byte[]{(byte) 0xFE, (byte) Math.max(0, Math.min(240, minutes))});
        flushWrites();
    }

    private void flushWrites() {
        if (writing || pending.isEmpty() || !connected || gatt == null || speedCharacteristic == null) return;
        byte[] next = pending.pollFirst();
        writing = true;
        try {
            boolean ok;
            if (Build.VERSION.SDK_INT >= 33) {
                ok = gatt.writeCharacteristic(speedCharacteristic, next,
                        BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT) == BluetoothGatt.GATT_SUCCESS;
            } else {
                speedCharacteristic.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
                speedCharacteristic.setValue(next);
                ok = gatt.writeCharacteristic(speedCharacteristic);
            }
            if (!ok) {
                writing = false;
                js("window.app.onSendError();");
            }
        } catch (Exception ex) {
            writing = false;
            js("window.app.onSendError();");
        }
    }

    private final class Bridge {
        @JavascriptInterface public void scan() { runOnUiThread(() -> startScan()); }
        @JavascriptInterface public void stopScanning() { runOnUiThread(() -> stopScan()); }
        @JavascriptInterface public void connect(String address) { runOnUiThread(() -> MainActivity.this.connect(address)); }
        @JavascriptInterface public void disconnect() { runOnUiThread(() -> MainActivity.this.disconnect()); }
        @JavascriptInterface public void setSpeed(int speed) { runOnUiThread(() -> queueSpeed(speed)); }
        @JavascriptInterface public void setSleepTimer(int minutes) { runOnUiThread(() -> queueSleep(minutes)); }
        @JavascriptInterface public boolean isAvailable() { return adapter != null; }
    }

    @Override public void onDestroy() {
        stopScan();
        disconnect();
        if (webView != null) { webView.destroy(); webView = null; }
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        js("window.app.back();");
    }
}
