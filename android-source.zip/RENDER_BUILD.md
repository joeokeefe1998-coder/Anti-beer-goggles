# Build Anti-Beer Goggles APK on Render

**Status:** This package is source code and Render configuration; the APK has NOT been built or tested.

## How the build works

1. Put the contents of this directory (not the outer ZIP) into a Git repository. A GitHub repository is easiest.
2. Connect the repository to Render. Deploy as a Docker web service using `Dockerfile`, or use the included `render.yaml` as a Blueprint.
3. Choose the free plan if available. The `Dockerfile` downloads the Android SDK, builds a *debug-signed* APK using Gradle, and hosts the APK with a tiny web server.
4. After Render finishes successfully, open the service address and select **Download Android APK**.
5. Alternatively download directly from `https://YOUR-SERVICE.onrender.com/Anti-Beer-Goggles-debug.apk`.
6. Install on your Android device for testing and flash the supplied ESP32-S3 Mini firmware using Arduino IDE.

## Limitations

* No real Render build or device test has taken place yet.
* Requires Render to have network access to Google Android SDK and Gradle repositories and adequate build resources.
* Public Render services expose the debug APK to anyone with its URL. Do not include secrets or sensitive credentials.
* The APK has a debug signature and is not a Play Store release.
* Render services build and host software; Render by itself cannot compile a ZIP attached to a ChatGPT conversation. The Git repository step is mandatory for this workflow.
* The ESP32 and the 3V fan power supply must be wired properly. See `WIRING.md`.
* Disconnect/stop fan power before changing wiring. Test MOSFET, PWM, flyback protection suitability, and battery readings on the actual hardware.
