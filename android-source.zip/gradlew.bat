@echo off
setlocal
rem Local bootstrap JAR source is at gradle\wrapper\GradleWrapperMain.java.
java -cp "%~dp0gradle\wrapper\gradle-wrapper.jar" org.gradle.wrapper.GradleWrapperMain %*
exit /b %errorlevel%
