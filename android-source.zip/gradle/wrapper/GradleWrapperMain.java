package org.gradle.wrapper;

// Small, fully source-included Gradle bootstrapper for this shared Android Studio project.
// This is NOT the official Gradle wrapper JAR. It fetches the pinned official Gradle
// 8.9 distribution from services.gradle.org and verifies its SHA-256 before use.
// Replace this JAR with the official Gradle 8.9 wrapper JAR if preferred.

import java.io.*;
import java.net.URL;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.zip.*;

public class GradleWrapperMain {
    private static final String URL = "https://services.gradle.org/distributions/gradle-8.9-bin.zip";
    private static final String SHA256 = "d725d707bfabd4dfdc958c624003b3c80accc03f7037b5122c4b1d0ef15cecab";

    public static void main(String[] args) throws Exception {
        String homeName = System.getenv("GRADLE_USER_HOME");
        Path home = Paths.get(homeName != null && !homeName.isEmpty() ? homeName :
                    System.getProperty("user.home") + File.separator + ".gradle");
        Path cache = home.resolve("wrapper").resolve("dists").resolve("anti-beer-goggles");
        Path executable = cache.resolve("gradle-8.9").resolve("bin").resolve(isWindows()?"gradle.bat":"gradle");
        if (!Files.isRegularFile(executable)) {
            Files.createDirectories(cache);
            Path zip = cache.resolve("gradle-8.9-bin.zip");
            if (!Files.isRegularFile(zip) || !SHA256.equalsIgnoreCase(sha256(zip))) {
                System.out.println("Downloading official Gradle 8.9 (one-time, ~130 MB)…");
                Path temp = cache.resolve("download.tmp");
                try (InputStream in = new URL(URL).openStream()) {
                    Files.copy(in, temp, StandardCopyOption.REPLACE_EXISTING);
                }
                if (!SHA256.equalsIgnoreCase(sha256(temp))) {
                    Files.deleteIfExists(temp);
                    throw new IOException("Gradle distribution checksum mismatch. Aborting.");
                }
                Files.move(temp, zip, StandardCopyOption.REPLACE_EXISTING);
            }
            System.out.println("Extracting Gradle…");
            try (ZipInputStream zis = new ZipInputStream(Files.newInputStream(zip))) {
                ZipEntry entry;
                while ((entry = zis.getNextEntry()) != null) {
                    Path out = cache.resolve(entry.getName()).normalize();
                    if (!out.startsWith(cache)) throw new IOException("Unsafe archive entry");
                    if (entry.isDirectory()) Files.createDirectories(out);
                    else {
                        Files.createDirectories(out.getParent());
                        Files.copy(zis, out, StandardCopyOption.REPLACE_EXISTING);
                    }
                    zis.closeEntry();
                }
            }
            executable.toFile().setExecutable(true);
        }
        List<String> command = new ArrayList<>();
        if (isWindows()) {command.add("cmd.exe");command.add("/c");}
        command.add(executable.toString());
        command.addAll(Arrays.asList(args));
        Process process = new ProcessBuilder(command).inheritIO().start();
        System.exit(process.waitFor());
    }
    private static boolean isWindows() { return System.getProperty("os.name").toLowerCase(Locale.ROOT).contains("win"); }
    private static String sha256(Path path) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        try (InputStream in = Files.newInputStream(path)) {
            byte[] buf = new byte[1024 * 64]; int n;
            while ((n = in.read(buf)) != -1) digest.update(buf, 0, n);
        }
        StringBuilder sb = new StringBuilder();
        for (byte b : digest.digest()) sb.append(String.format("%02x", b & 255));
        return sb.toString();
    }
}
