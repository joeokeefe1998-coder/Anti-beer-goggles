# ANTI-BEER GOGGLES — Android + ESP32-S3 Mini

**Alpha 1.0 source project — NOT a compiled APK.**

This is a native Android app with an HTML/CSS view for the user's approved THICK ASS-style design: a solid black background, muted green borders and headers, white settings labels, and smoky/soft green brush lettering for the title only. The included title artwork is cropped from the approved design reference. Unlike the mock-up, Bluetooth devices and battery values shown in the app are real data rather than invented examples.

## Features implemented

- Phone-to-ESP32-S3 Bluetooth Low Energy (BLE) connection and scanning
- Fan OFF/LOW/MED/HIGH presets (defaults: 0/40/65/100%)
- 0–100% fan speed slider, +/- controls, fan toggle
- Low/medium/high preset customisation stored on phone
- Battery percentage and voltage from a 2 x 10kΩ LiPo voltage divider on GPIO1
- Low battery in-app warning (user-adjustable threshold)
- Sleep timer, including continuing after phone disconnects (requires matching ESP32 firmware)
- Bluetooth info, settings, connection screen
- Offline by design, with **no Internet permission, telemetry or account**

## Build an Android APK on a Windows, Mac or Linux computer

1. Install **Android Studio** and its Android SDK Platform 35 + Build-Tools through its SDK Manager. Use the bundled JDK 17 or another compatible JDK 17.
2. Unzip this project, open the **AntiBeerGoggles_AndroidStudio** folder through Android Studio's **File > Open**.
3. Allow Gradle sync to finish. Internet is needed for the *first* Gradle and Android Gradle plugin download.
4. Go to **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. When the build succeeds, retrieve `app/build/outputs/apk/debug/app-debug.apk`. Copy to Android phone, open it, and allow installation from that file manager if prompted.
6. On the ESP32-S3 Mini, flash the companion sketch `esp32_firmware/AntiBeerGoggles_S3/AntiBeerGoggles_S3.ino` from Arduino IDE first. Select the correct ESP32-S3 board in Arduino IDE. You'll need the Espressif ESP32 Arduino core, with its bundled BLE library.
7. Power the ESP32-S3, enable Bluetooth on your phone, open **ANTI-BEER GOGGLES**, grant Nearby Devices access, select Bluetooth, scan and connect to `AntiBeerGoggles`.

**Important build note:** This source package includes a tiny *custom* Gradle bootstrap jar (with full source `gradle/wrapper/GradleWrapperMain.java`) because the official Gradle wrapper could not be fetched in the authoring environment. It securely pins Gradle 8.9 and validates the downloaded distribution's SHA-256 hash. If you prefer the standard wrapper, replace the jar using Gradle's official `gradle wrapper --gradle-version 8.9` command from an installed Gradle or replace it with the official Gradle 8.9 wrapper jar. The downloaded distribution will be cached in `~/.gradle/wrapper/dists/anti-beer-goggles`.

**This source was not built on Android tooling or checked against the real fan.** The HTML/JavaScript syntax, project manifest structure and BLE UUID agreement were checked. The first real APK build and phone/ESP hardware tests still need to be done.

## Electrical wiring

See [WIRING.md](WIRING.md). Hardware must be wired safely: do **not** connect a 3V fan directly to an ESP GPIO or the 5V boost output, and never connect LiPo positive directly to the ESP32 ADC pin.

## BLE protocol used by both app and firmware

| Characteristic UUID | Properties | Payload |
| --- | --- | --- |
| `c83e0002-7cc4-4f8a-a0ad-0d2041151337` | Read, Write | `0..100` (1 byte fan %), or `[0xFE, minutes]` (2-byte sleep timer) |
| `c83e0003-7cc4-4f8a-a0ad-0d2041151337` | Read, Notify | `[battery %, mV low byte, mV high byte]` (3 bytes) |

Service UUID: `c83e0001-7cc4-4f8a-a0ad-0d2041151337`.

BLE advertisement name: `AntiBeerGoggles`.

## Known limitations

- Alpha build; Android permissions and hardware need testing on your actual phone/ESP32-S3.
- The battery percentage is only an estimate based on battery voltage and will vary with fan load.
- The fan may require a minimum PWM duty cycle to operate reliably. A 350ms full-power startup pulse is included.
- This firmware expects a 2-wire 3V fan whose power can be switched via MOSFET PWM. Verify the specific fan is compatible.
- Sleep timer resets if the ESP32 itself loses power or reboots.
- Fan is OFF after ESP32 boot for safety. Disconnecting the phone does not stop a running fan.
- Presets and warning threshold are saved locally on the phone; sleep timer only exists on the powered ESP32.
- No manual hardware speed control is required.
- This project does not implement LiPo charging or cell-protection logic.
