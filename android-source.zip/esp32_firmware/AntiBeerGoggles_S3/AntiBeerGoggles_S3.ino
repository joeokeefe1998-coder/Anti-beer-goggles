/*
  ANTI-BEER GOGGLES — ESP32-S3 Mini firmware
  Requires Arduino ESP32 core (ESP32-S3 board) and included ESP32 BLE library.

  Fan: GPIO4 -> 100..220 ohm resistor -> logic-level MOSFET gate
       10k resistor MOSFET gate -> GND
       MOSFET source -> GND; drain -> FAN (-)
       FAN (+) -> REGULATED 3.0 V (NOT ESP32 GPIO or 5 V!)
       All supply and ESP grounds interconnected.

  Battery ADC, 1-cell LiPo 3.0-4.2 V: LiPo+ -> 10k -> GPIO1 -> 10k -> GND.
  ESP powered from properly regulated 5 V boost into labelled 5V/VIN board input
  only when appropriate for your actual ESP32-S3 Mini board.

  BLE service c83e0001-7cc4-4f8a-a0ad-0d2041151337
  Fan char    c83e0002-7cc4-4f8a-a0ad-0d2041151337   READ/WRITE:
      [0..100]         => set fan speed as percent
      [0xFE, minutes]  => turn fan off automatically after 0..240 minutes
  Battery     c83e0003-7cc4-4f8a-a0ad-0d2041151337   READ/NOTIFY:
      [percentage, battery_mV_low, battery_mV_high]

  Battery % is a voltage-based approximation, not a battery fuel gauge.
*/

#include <Arduino.h>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>
#include <esp_arduino_version.h>

static constexpr uint8_t FAN_PIN = 4;
static constexpr uint8_t BATTERY_ADC_PIN = 1;
static constexpr uint32_t PWM_FREQUENCY = 25000; // Audible noise is less likely.
static constexpr uint8_t PWM_BITS = 8;
static constexpr uint8_t PWM_CHANNEL = 0;
static constexpr uint32_t REPORT_EVERY_MS = 5000;
static constexpr uint32_t START_KICK_MS = 350;

#define BLE_NAME "AntiBeerGoggles"
#define BLE_SERVICE_UUID "c83e0001-7cc4-4f8a-a0ad-0d2041151337"
#define BLE_SPEED_UUID "c83e0002-7cc4-4f8a-a0ad-0d2041151337"
#define BLE_BATTERY_UUID "c83e0003-7cc4-4f8a-a0ad-0d2041151337"

static BLEServer *bleServer = nullptr;
static BLECharacteristic *speedCharacteristic = nullptr;
static BLECharacteristic *batteryCharacteristic = nullptr;
static volatile bool bleConnected = false;
static volatile uint8_t fanTarget = 0;
static uint32_t kickEndsAt = 0;
static uint32_t sleepEndsAt = 0;
static uint32_t lastReportAt = 0;

void rawPwm(uint8_t duty) {
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcWrite(FAN_PIN, duty);
#else
  ledcWrite(PWM_CHANNEL, duty);
#endif
}

uint8_t dutyForPercent(uint8_t percent) {
  return (uint8_t)((uint16_t)percent * 255U / 100U);
}

void publishFanSpeed() {
  if (speedCharacteristic) {
    uint8_t value = fanTarget;
    speedCharacteristic->setValue(&value, 1);
  }
}

void changeFanSpeed(uint8_t percent) {
  if (percent > 100) return;
  uint8_t before = fanTarget;
  fanTarget = percent;
  if (!percent) {
    kickEndsAt = 0;
    rawPwm(0);
  } else if (!before) {
    // Full power briefly to help a small brushless fan start spinning.
    rawPwm(255);
    kickEndsAt = millis() + START_KICK_MS;
  } else if (kickEndsAt == 0) {
    rawPwm(dutyForPercent(percent));
  }
  publishFanSpeed();
  Serial.printf("Fan target: %u%%\n", percent);
}

struct VoltagePoint { uint16_t mv; uint8_t percent; };
static const VoltagePoint voltageCurve[] = {
  {3000, 0}, {3300, 5}, {3500, 12}, {3600, 20},
  {3700, 35}, {3750, 45}, {3800, 55}, {3850, 65},
  {3900, 75}, {4000, 88}, {4100, 96}, {4200, 100}
};

uint8_t estimatePercent(uint16_t millivolts) {
  if (millivolts <= voltageCurve[0].mv) return 0;
  const size_t count = sizeof(voltageCurve) / sizeof(voltageCurve[0]);
  for (size_t i = 1; i < count; ++i) {
    if (millivolts <= voltageCurve[i].mv) {
      const VoltagePoint a = voltageCurve[i - 1], b = voltageCurve[i];
      return a.percent + (uint32_t)(millivolts - a.mv) * (b.percent - a.percent) / (b.mv - a.mv);
    }
  }
  return 100;
}

uint16_t readBatteryMillivolts() {
  // Each 10k resistor divides battery voltage in half.
  // analogReadMilliVolts provides calibrated ADC voltage on ESP32 Arduino core.
  uint32_t sampleSum = 0;
  for (int i = 0; i < 24; ++i) {
    sampleSum += (uint32_t)analogReadMilliVolts(BATTERY_ADC_PIN);
    delayMicroseconds(350);
  }
  uint32_t batteryMv = (sampleSum / 24) * 2;
  return (uint16_t)min(batteryMv, (uint32_t)6000);
}

void sendBatteryReading() {
  uint16_t mv = readBatteryMillivolts();
  uint8_t batteryPayload[] = {estimatePercent(mv), (uint8_t)(mv & 0xff), (uint8_t)(mv >> 8)};
  batteryCharacteristic->setValue(batteryPayload, sizeof(batteryPayload));
  if (bleConnected) batteryCharacteristic->notify();
  Serial.printf("Battery ~%u%% (%umV)\n", batteryPayload[0], mv);
}

class ServerCallbacks : public BLEServerCallbacks {
  void onConnect(BLEServer *server) override {
    bleConnected = true;
    Serial.println("Android app connected");
  }
  void onDisconnect(BLEServer *server) override {
    bleConnected = false;
    // Don't stop the fan: retain selected speed and running sleep timer.
    server->startAdvertising();
    Serial.println("App disconnected; advertising again");
  }
};

class FanCallbacks : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic *characteristic) override {
    auto payload = characteristic->getValue();
    if (payload.length() == 1) {
      uint8_t requested = (uint8_t)payload[0];
      if (requested <= 100) changeFanSpeed(requested);
    } else if (payload.length() == 2 && (uint8_t)payload[0] == 0xFE) {
      uint8_t minutes = (uint8_t)payload[1];
      sleepEndsAt = minutes == 0 ? 0 : millis() + ((uint32_t)minutes * 60000UL);
      Serial.printf("Sleep timer: %u minute(s)\n", minutes);
    }
  }
};

void setup() {
  Serial.begin(115200);
  pinMode(FAN_PIN, OUTPUT);
  digitalWrite(FAN_PIN, LOW);
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  if (!ledcAttach(FAN_PIN, PWM_FREQUENCY, PWM_BITS)) {
    Serial.println("ERROR: Could not attach PWM to GPIO4");
  }
#else
  ledcSetup(PWM_CHANNEL, PWM_FREQUENCY, PWM_BITS);
  ledcAttachPin(FAN_PIN, PWM_CHANNEL);
#endif
  rawPwm(0);
  analogReadResolution(12);
  analogSetPinAttenuation(BATTERY_ADC_PIN, ADC_11db);
  pinMode(BATTERY_ADC_PIN, INPUT);

  BLEDevice::init(BLE_NAME);
  bleServer = BLEDevice::createServer();
  bleServer->setCallbacks(new ServerCallbacks());
  BLEService *service = bleServer->createService(BLE_SERVICE_UUID);

  speedCharacteristic = service->createCharacteristic(
    BLE_SPEED_UUID, BLECharacteristic::PROPERTY_READ | BLECharacteristic::PROPERTY_WRITE);
  speedCharacteristic->setCallbacks(new FanCallbacks());
  publishFanSpeed();

  batteryCharacteristic = service->createCharacteristic(
    BLE_BATTERY_UUID, BLECharacteristic::PROPERTY_READ | BLECharacteristic::PROPERTY_NOTIFY);
  batteryCharacteristic->addDescriptor(new BLE2902());
  sendBatteryReading();

  service->start();
  BLEAdvertising *advertising = BLEDevice::getAdvertising();
  advertising->addServiceUUID(BLE_SERVICE_UUID);
  advertising->setScanResponse(true);
  advertising->start();
  Serial.println("AntiBeerGoggles BLE advertising. Fan OFF at boot.");
}

void loop() {
  uint32_t now = millis();
  if (kickEndsAt && (int32_t)(now - kickEndsAt) >= 0) {
    kickEndsAt = 0;
    rawPwm(dutyForPercent(fanTarget));
  }
  if (sleepEndsAt && (int32_t)(now - sleepEndsAt) >= 0) {
    sleepEndsAt = 0;
    changeFanSpeed(0);
    Serial.println("Sleep timer completed: fan stopped");
  }
  if ((uint32_t)(now - lastReportAt) >= REPORT_EVERY_MS) {
    lastReportAt = now;
    sendBatteryReading();
  }
  delay(10);
}
